##### SRO_related

Extract ordering info. from the spatial/frequency domain of atomic signals.